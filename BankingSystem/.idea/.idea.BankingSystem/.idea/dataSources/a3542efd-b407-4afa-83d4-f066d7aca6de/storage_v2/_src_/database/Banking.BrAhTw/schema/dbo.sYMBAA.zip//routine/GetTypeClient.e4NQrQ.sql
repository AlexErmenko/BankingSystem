CREATE FUNCTION GetTypeClient(@id INT)
RETURNS NVARCHAR(MAX)
BEGIN

declare @s VARCHAR(100);
declare @txt NVARCHAR(MAX);
set @txt = '';

IF(EXISTS(SELECT * FROM physical_person WHERE id_person = @id))
	set @txt = 'Физическое лицо'
ELSE set @txt = 'Юридическое лицо'

RETURN @txt

END
go

